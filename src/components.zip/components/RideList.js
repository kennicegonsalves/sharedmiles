import { useEffect, useState, useContext } from 'react';
import { ref, query, orderByChild, equalTo, onValue, off, set } from 'firebase/database';
import { realTimeDb } from "../firebase";
import { Context } from '../Context';

function RideList() {
  const [rideRequests, setRideRequests] = useState([]);
  const { user, setIsLoading, setCurrentRide, setSelectedFrom, setSelectedTo } = useContext(Context);

  useEffect(() => {
    const rideRef = query(ref(realTimeDb, 'rides'), orderByChild('status'), equalTo(0));
    const listener = onValue(rideRef, (snapshot) => {
      const values = snapshot.val();
      const rides = values ? Object.values(values) : [];
      setRideRequests(rides);
    });

    return () => off(rideRef);
  }, []);

  const acceptRide = (request) => {
    request.driver = user;
    request.status = 1;
    setIsLoading(true);

    const rideRef = ref(realTimeDb, `rides/${request.rideUuid}`);
    set(rideRef, request)
      .then(() => {
        setIsLoading(false);
        localStorage.setItem('currentRide', JSON.stringify(request));
        setCurrentRide(request);
        setSelectedFrom(request.pickup);
        setSelectedTo(request.destination);
      })
      .catch((error) => {
        console.error('Failed to accept ride:', error);
        setIsLoading(false);
      });
  };

  const renderRideList = () => {
    // Check if rideRequests is empty and render a message
    if (rideRequests.length === 0) {
      return <h3 className="empty-message">You do not have any requests</h3>;
    }
    
    // Render ride requests if available
    return rideRequests.map((request) => (
      <div className="ride-list__result-item" key={request.rideUuid}>
        <p><span><b>From:</b> <br /></span>{request.pickup || 'N/A'}</p>
        <p><span><b>To:</b> <br /></span>{request.destination || 'N/A'}</p>
        <button className="ride-list__accept-btn" onClick={() => acceptRide(request)}>Accept</button>
      </div>
    ));
  };

  return (
    <div className="ride-list">
      <div className="ride-list__container">
        <div className="ride-list__title">Ride Requests</div>
      </div>
      <div className="ride-list__content">
        {renderRideList()}
      </div>  
    </div>
  );
}

export default RideList;
