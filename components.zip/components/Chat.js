function Chat(){
    return(
        <h1>hello world</h1>
    )
}

export default Chat;